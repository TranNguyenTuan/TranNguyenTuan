﻿using NhaHang9999.DAO;
using NhaHang9999.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NhaHang9999
{
    public partial class AccountProfile : Form
    {
       
        
            private Account loginAccount;
            public Account LoginAccount
            {
                get { return loginAccount; }
                set { loginAccount = value; ChangeAccount(loginAccount); }
            }
        void ChangeAccount(Account acc)
        {
            txbUserName.Text = LoginAccount.UserName;
            txbDisPlayName.Text = LoginAccount.DisplayName;
        }

        public AccountProfile(Account acc )
        {
            InitializeComponent();
            LoginAccount = acc;
            }
       
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        void UpdateAccount()
        {
            string displayName = txbDisPlayName.Text;
            string password = txbPass.Text;
            string newpass = txbNewPass.Text;
            string reenterPass = txbReEnterPass.Text;
            string userName = txbUserName.Text;

            if (!newpass.Equals(reenterPass))
            {
                MessageBox.Show("Vui lòng nhập lại mật khẩu ");
            }
            else
            {
                if (AccountDAO.Instance.UpdateAccount(userName, displayName, password, newpass))
                {
                    MessageBox.Show("Cập nhật thành công");
                }
                else
                {
                    MessageBox.Show("Nhập lại mật khẩu");
                }
            }
        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateAccount();
        }
    }
}
